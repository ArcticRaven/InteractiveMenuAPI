package dev.arctic.interactivemenuapi.animation;

public enum AnimationType{
    NONE,
    LEFT,
    RIGHT,
    UP,
    DOWN,
    VISIBILITY,
    FORWARD,
    BACKWARD,
    PRESSED
}